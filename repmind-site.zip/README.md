
# REPMind.AI Landing (Next.js + Tailwind)

## Quick start
```bash
npm i
npm run dev
# open http://localhost:3000
```

## Deploy to Vercel
1) Push this folder to a new GitHub repo (or import in Vercel directly).
2) In Vercel: New Project → Import repo → Framework auto-detected.
3) Add your custom domain later (Domains → Add).

### Customize
- Replace the `Book a Demo` form submit with your Calendly link in `components/Landing.tsx`.
- Update feature copy, case studies, and pricing there as well.
