
'use client';
import { useState } from "react";
import { Calendar, CheckCircle, BarChart2, Shield, Zap, Brain, Mail } from "lucide-react";

export default function Landing() {
  const [email, setEmail] = useState("");

  const features = [
    { title: "Real‑time call coaching", desc: "Live cues on questions, talk ratio, objection handling, and next steps.", icon: Zap, bg: "bg-amber-100 text-amber-700" },
    { title: "Confidence analytics", desc: "Track behaviors that correlate to rep confidence and win‑rate.", icon: BarChart2, bg: "bg-indigo-100 text-indigo-700" },
    { title: "Playbooks that adapt", desc: "Dynamic prompts tuned to your industry and scripts.", icon: Brain, bg: "bg-sky-100 text-sky-700" },
    { title: "CRM friendly", desc: "Auto‑log notes & next steps to your existing workflow.", icon: CheckCircle, bg: "bg-emerald-100 text-emerald-700" },
    { title: "Privacy first", desc: "Granular controls for recording, redaction, and retention.", icon: Shield, bg: "bg-slate-100 text-slate-700" },
    { title: "Fast setup", desc: "Get value on day one—no heavy IT project required.", icon: Zap, bg: "bg-purple-100 text-purple-700" },
  ];

  const pricing = [
    { name:"Starter", price:"$29/rep", note:"billed monthly", emph:false, items:["Live tips (core)", "Weekly summary", "Email support"]},
    { name:"Growth", price:"$59/rep", note:"popular", emph:true, items:["All Starter", "Real‑time scoring", "CRM sync", "Playbooks"]},
    { name:"Business", price:"Custom", note:"10+ seats", emph:false, items:["All Growth", "Advanced analytics", "SAML/SSO", "Dedicated success"]},
  ];

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <div className="w-full bg-slate-900 text-white text-center text-sm py-2">
        <span className="opacity-80">AI-powered sales coaching, built for SMBs.</span>
      </div>

      <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-500 grid place-items-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold tracking-tight">REPMind.AI</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm">
            <a href="#features" className="hover:text-slate-600">Features</a>
            <a href="#pricing" className="hover:text-slate-600">Pricing</a>
            <a href="#cases" className="hover:text-slate-600">Case Studies</a>
            <a href="#about" className="hover:text-slate-600">About Us</a>
          </nav>
          <div className="flex items-center gap-3">
            <a href="#demo" className="hidden sm:inline-flex items-center rounded-2xl px-4 py-2 text-sm font-semibold bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm">Book a Demo</a>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_left,rgba(59,130,246,0.15),transparent_40%),radial-gradient(ellipse_at_bottom_right,rgba(99,102,241,0.18),transparent_40%)]"/>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-indigo-600 font-semibold tracking-wide">Unlock Your Team’s Full Potential</p>
            <h1 className="mt-3 text-4xl sm:text-5xl font-extrabold leading-tight">
              AI‑Powered Sales Coaching & Real‑Time Insights
            </h1>
            <p className="mt-4 text-lg text-slate-600 max-w-2xl">
              Give every rep a coach in their ear. REPMind.AI analyzes conversations, builds confidence, and turns good calls into closed deals.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <a href="#demo" className="inline-flex items-center justify-center rounded-2xl px-6 py-3 text-base font-semibold bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/20">Book a Demo</a>
              <a href="#features" className="inline-flex items-center justify-center rounded-2xl px-6 py-3 text-base font-semibold border border-slate-300 hover:bg-slate-50">See Features</a>
            </div>
            <div className="mt-6 flex items-center gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-600"/>Easy setup</div>
              <div className="flex items-center gap-2"><Shield className="w-4 h-4 text-sky-600"/>SOC2‑ready approach</div>
              <div className="flex items-center gap-2"><Zap className="w-4 h-4 text-amber-500"/>Real‑time guidance</div>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-3xl border border-slate-200 shadow-2xl overflow-hidden bg-slate-900 text-slate-100">
              <div className="bg-slate-800 px-4 py-3 flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500"/>
                <div className="w-3 h-3 rounded-full bg-amber-400"/>
                <div className="w-3 h-3 rounded-full bg-emerald-500"/>
                <span className="ml-2 text-xs opacity-70">REPMind.AI • Live Demo</span>
              </div>
              <div className="p-8 sm:p-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-500 grid place-items-center">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold">REPMind.AI</h3>
                </div>
                <p className="mt-2 text-slate-300">"Coach Mode" active · Confidence boost +18%</p>
                <div className="mt-6 grid grid-cols-2 gap-4">
                  {[
                    {label: "Live tips", value: "+12"},
                    {label: "Talk‑time balance", value: "54/46"},
                    {label: "Objection wins", value: "7/9"},
                    {label: "Next steps set", value: "92%"},
                  ].map((m, i) => (
                    <div key={i} className="rounded-2xl border border-slate-700 bg-slate-800/60 p-4">
                      <div className="text-sm text-slate-400">{m.label}</div>
                      <div className="mt-1 text-2xl font-semibold">{m.value}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 rounded-2xl border border-slate-700 p-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    <BarChart2 className="w-5 h-5"/>
                    Real‑time call scoring
                  </div>
                  <div className="mt-2 h-24 rounded-xl bg-gradient-to-r from-indigo-500/30 via-sky-500/30 to-emerald-500/30"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight">Everything your reps need to win</h2>
          <p className="mt-2 text-slate-600 max-w-2xl">Designed around one truth: confidence is the #1 indicator of a successful sales rep.</p>
          <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <div key={i} className="rounded-3xl bg-white border border-slate-200 p-6 shadow-sm">
                <div className={`w-10 h-10 rounded-xl grid place-items-center ${f.bg}`}>
                  <f.icon className="w-5 h-5"/>
                </div>
                <h3 className="mt-4 font-semibold text-lg">{f.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="cases" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Case Studies</h2>
              <p className="text-slate-600 mt-2">Real results from real teams.</p>
            </div>
            <a href="#demo" className="rounded-2xl px-4 py-2 bg-slate-900 text-white text-sm font-semibold">Book a Demo</a>
          </div>
          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {[
              {title:"Home Services SMB", stat:"+22% close rate", desc:"3 months to measurable lift using live guidance."},
              {title:"Insurance Call Center", stat:"-31% cancellations", desc:"Confidence playbooks reduced uncertainty."},
              {title:"B2B SaaS", stat:"+18% meetings set", desc:"Real‑time objection handling and next‑step prompts."},
            ].map((c, i)=> (
              <article key={i} className="rounded-3xl border border-slate-200 p-6 hover:shadow-lg transition-shadow">
                <div className="text-xs uppercase tracking-wider text-indigo-600 font-semibold">{c.title}</div>
                <h3 className="mt-2 text-xl font-bold">{c.stat}</h3>
                <p className="mt-2 text-sm text-slate-600">{c.desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="pricing" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight text-center">Simple, transparent pricing</h2>
          <p className="mt-2 text-slate-600 text-center max-w-2xl mx-auto">Start small, scale as your team grows.</p>
          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {pricing.map((p, i)=> (
              <div key={i} className={`rounded-3xl border ${p.emph? 'border-indigo-300 ring-2 ring-indigo-200': 'border-slate-200'} bg-white p-6 shadow-sm flex flex-col`}>
                <div className="text-sm font-semibold text-slate-900">{p.name}</div>
                <div className="mt-2 text-4xl font-extrabold">{p.price}</div>
                <div className="text-sm text-slate-500">{p.note}</div>
                <ul className="mt-4 space-y-2 text-sm text-slate-600">
                  {p.items.map((it, idx)=> (
                    <li key={idx} className="flex gap-2"><CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5"/>{it}</li>
                  ))}
                </ul>
                <a href="#demo" className={`mt-6 inline-flex justify-center rounded-2xl px-4 py-2 font-semibold ${p.emph? 'bg-indigo-600 text-white hover:bg-indigo-700':'border border-slate-300 hover:bg-slate-50'}`}>Choose {p.name}</a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight">About REPMind.AI</h2>
          <p className="mt-4 text-slate-600">We’re sales coaches, data nerds, and product builders. We believe the fastest way to better revenue is building confident reps—supported by real-time, research-backed insights.</p>
          <div id="demo" className="mt-10 rounded-3xl border border-slate-200 p-6 max-w-xl mx-auto">
            <div className="flex items-center justify-center gap-2">
              <Calendar className="w-5 h-5"/>
              <span className="font-semibold">Book a 20‑minute demo</span>
            </div>
            <form className="mt-5 flex gap-2" onSubmit={(e)=>{e.preventDefault(); alert(`Thanks! We'll reach out to ${email}`);}}>
              <input value={email} onChange={(e)=> setEmail(e.target.value)} type="email" required placeholder="you@company.com" className="flex-1 rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-200"/>
              <button className="inline-flex items-center gap-2 rounded-2xl px-5 py-3 bg-slate-900 text-white font-semibold hover:bg-slate-800"><Mail className="w-4 h-4"/>Request Demo</button>
            </form>
            <p className="mt-2 text-xs text-slate-500">Or connect your Calendly link in code.</p>
          </div>
        </div>
      </section>

      <footer className="py-10 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-slate-600 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-500 grid place-items-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold">REPMind.AI</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <a href="#" className="hover:text-slate-900">Terms</a>
            <a href="#" className="hover:text-slate-900">Contact</a>
          </div>
          <p className="opacity-70">© {new Date().getFullYear()} REPMind.AI</p>
        </div>
      </footer>
    </div>
  );
}
