
export const metadata = {
  title: "REPMind.AI",
  description: "AI‑Powered Sales Coaching & Real‑Time Insights",
};
import "./globals.css";
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
